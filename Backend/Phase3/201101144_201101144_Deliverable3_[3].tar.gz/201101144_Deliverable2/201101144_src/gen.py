f=open("test","r");
g=f.readlines()
for i in range(1000):
	for j in g:
		print str(j),
