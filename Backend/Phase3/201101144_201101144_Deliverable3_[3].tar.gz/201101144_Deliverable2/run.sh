cd 201101144_src
echo $PWD
make -f Makefile.linux 
./out

